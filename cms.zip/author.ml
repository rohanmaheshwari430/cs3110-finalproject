let hours_worked = 0
